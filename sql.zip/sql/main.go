package main

import "log"

func main() {
	var sqlname string //数据库名称
	var tab string     //表格名称
	sqlname = "bookstore0612"
	tab = "book"
	dbInfo := &DBInfo{
		DBType:   "mysql",
		Host:     "127.0.0.1:3306",
		UserName: "root",
		Password: "xxx",
		Charset:  "utf8mb4",
	}
	dbModel := NewDBModel(dbInfo)
	err := dbModel.Connect()
	if err != nil {
		log.Fatal(err)
	}
	columns, err := dbModel.GetColumns(sqlname, tab)
	if err != nil {
		log.Fatal(err)
	}
	template := NewStructTemplate()
	templateCoumns := template.AssemblyColumns(columns)
	err = template.Generate(tab, templateCoumns)
	if err != nil {
		log.Fatal(err)
	}
}
